# vehicle detection > 2022-08-31 4:27pm
https://universe.roboflow.com/object-detection/vehicle-detection-cd5qp

Provided by Roboflow
License: CC BY 4.0

